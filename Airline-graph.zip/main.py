"""
*Airline safety is based on number of miles travelled vs. number of incidents/fatalaties
Questions answered: Which airline is the safest airline? Which airline is the most unsafe? What is the projection of safety in airlines? Number of incidents vs fatalities? 1. What are some of the safest airlines in relation to the number of miles travelled vs. number of incidents? What are some of the best according to the number of incidents and fatilities (distance is not included)?
Graphs to express data: Line graph (show the trend of airline safety over the years). Scatterplot (show the comparison between the number of incidents vs. mileage of airplane). Bar graphs comparing the last two questions.
1. Airlines with practically no incidents, but few miles: 
"""
import csv
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

airlines = []
milesAirline = {}
recentAirlineIncidents = {}
recentMilesIncidents = {} #Graph this (scatterplot)
oldAirlineIncidents = {}
oldMilesIncidents = {} #Graph this (scatterplot)
recentIncidentsFatalities = {}
oldIncidentsFatalities = {}
recentFatalities = {}
with open('airline-safety.csv', encoding='utf-8') as file:  
    reader = csv.DictReader(file)
    for row in reader:
        airlines.append(row['airline'])
        milesAirline[row['airline']] = [row['avail_seat_km_per_week']]
        recentAirlineIncidents[row['airline']] = row['incidents_00_14']
        recentMilesIncidents[row['airline']] = [int(row['incidents_00_14'])/int(row['avail_seat_km_per_week'])]
        oldAirlineIncidents[row['airline']] = row['incidents_85_99']
        oldMilesIncidents[row['airline']] = int(row['incidents_85_99'])/int(row['avail_seat_km_per_week'])
        recentIncidentsFatalities[int(row['incidents_00_14'])] = int(row['fatalities_00_14'])
        oldIncidentsFatalities[int(row['incidents_85_99'])] = int(row['fatalities_85_99'])
        recentFatalities[row['airline']] = row['fatalities_00_14']
oldIncidents = []
newIncidents = []
for airline in airlines:
  oldIncidents.append(int(oldAirlineIncidents[airline]))
  newIncidents.append(int(recentAirlineIncidents[airline]))
sns.scatterplot(oldIncidents,newIncidents)
plt.title("Old vs Recent Incidents")
plt.xlabel("Old Incidents")
plt.ylabel("Recent Incidents")
plt.savefig('oldVsNew.png')
plt.clf()

newFatalities = []
for airline in airlines:
  print(airline+"recent fatalities: "+recentFatalities[airline])
  newFatalities.append(int(recentFatalities[airline]))
sns.scatterplot(newIncidents, newFatalities)
plt.title("Incidents vs Fatalities")
plt.xlabel("Incidents")
plt.ylabel("Fatalities")
plt.savefig('incidentsVsFatalities')
plt.clf()

milesdf = pd.DataFrame(data = milesAirline)
milesgraph = sns.barplot(data=milesdf, palette="Blues_d")
milesgraph.set(title='Miles per Airline Graph', xlabel="Number", ylabel="Frequency", label = "small")
plt.xticks(rotation=90)
sns.set(font_scale=.5)
plt.savefig('milesgraph.png')
plt.clf()

recentIncidentsdf = pd.DataFrame(data = recentMilesIncidents)
recentIncidentsGraph = sns.barplot(data = recentIncidentsdf, palette = "Blues_d")
recentIncidentsGraph.set(title = "Ratio of Incidents to Miles Travelled by Airlines")
plt.xticks(rotation=90)
sns.set(font_scale=.75)
plt.savefig('recentMilesToIncidentsGraph.png')
plt.clf()

recentIncidentsSorted= sorted(recentMilesIncidents, key=recentMilesIncidents.get, reverse=True)
for i in range(len(recentIncidentsSorted)):
    print(recentIncidentsSorted[i])
    print(recentMilesIncidents[recentIncidentsSorted[i]])


"""
Finish all the questions (be willing to change as you go)
Create a dict with the miles travelled and the airline name
Create the ratio between the miles travelled and the incidents for the first set of data.

Feb 19:
Finish the current graph (make the x values legible)
Start and finish another possible graph
Answer questions (ones without the graphs)

Feb 27:
Read article that came with the data
A little background research on airplanes/airplane safety
Find a conclusion from this data
Make some more graphs (different types too)

March 6:
*Scatterplot of new vs old airline incidents/fatalities
*The second miles ratio grah for old data
*Talk about where the data came from
*Look at the article about the data
*Incidents vs. fatalities graphs
*Talk about why I chose this topic
*Add ALL this info to the slides and finish it up

# Maybe try to create user friendly tables
# Make the lables show up on the graph
"""

